This is a submission of the Inference Project of Term 2 of Robotics NanoDegree.
1. Folder: model_files_bottles_and_boxes_g_lenet_sgd_20180121-122409-eaed_epoch_5 has the files related to the trained model
2. Folder: project_images has images and screenshots captured during the course of the project
3. File: 9_evaluate_screenshot2_watermarked.jpg has the watermarked screenshot of the 'evaluate' command for the first part of the project
4. File: inference_project_report.pdf has the project report in the required format. The provided latex template was used.
